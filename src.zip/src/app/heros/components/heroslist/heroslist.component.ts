import { Component, OnInit } from '@angular/core';
import { HerosService } from '../../service/Heros.service';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { HerosStoreService } from '../../service/herosStoreService';

@Component({
  selector: 'app-heroslist',
  templateUrl: './heroslist.component.html',
  styleUrls: ['./heroslist.component.scss']
})
export class HeroslistComponent implements OnInit {
public heros = Array<any>();
heros$: Observable<any[]>;

  constructor(private herosService: HerosService,private herosStoreService: HerosStoreService) { }

  ngOnInit() {
      this.heros$ = this.herosStoreService.heros$;
     // this.getAllHeros();
  }
  //.map(res => this.data = res.json())
  getAllHeros(){
    this.herosService.getAllHeros().subscribe(data => {
     console.log(data);
     this.heros=  data;
    },erro =>{
      console.log(erro);
    })
  }

}
