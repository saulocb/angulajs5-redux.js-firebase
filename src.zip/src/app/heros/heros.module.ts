import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HerosListRoutingModule } from './heros-list-routing.module';
import { HerosService } from './service/Heros.service';
import { HeroslistComponent } from './components/heroslist/heroslist.component';
import { HttpModule } from '@angular/http';
import { StoreModule } from '@ngrx/store';
import { herosReducer } from './store/heros.reduce';
import { EffectsModule } from '@ngrx/effects';
import { HerosEffects } from './store/heros.effects';
import { HerosStoreService } from './service/herosStoreService';

@NgModule({
  imports: [
    CommonModule,
    HerosListRoutingModule,
    HttpModule,
    StoreModule.forRoot({
      heros: herosReducer
    }),
    EffectsModule.forRoot([HerosEffects])
  ],
  declarations: [HeroslistComponent],
  exports: [HeroslistComponent],
  providers: [HerosService,HerosStoreService]
})
export class HerosModule { }
