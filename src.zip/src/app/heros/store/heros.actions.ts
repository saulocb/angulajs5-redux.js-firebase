

import { Action } from '@ngrx/store';
import { type } from '../../ngrx/util';

export const ActionTypes = {
    LOAD: type('[Heros] -LOAD Requested-'),
    LOAD_COMPLETED: type('[Heros] -LOAD Completed-'),
    LOAD_ERROR: type('[Heros] -LOAD Error-')

};

export class LoadCompletedAction implements Action {
    type = ActionTypes.LOAD_COMPLETED;
    constructor(public payload: HerosPayload) { }
}

export class HerosPayload {
    constructor(public heros: any[]) { }
}

export class LoadAction implements Action {
    type = ActionTypes.LOAD;
    constructor(public payload: any = null) { }
}

export class LoadErrorAction implements Action {
    type = ActionTypes.LOAD_ERROR;

    constructor(public payload: string) { }
}


export type HerosAction
    = LoadAction
    | LoadCompletedAction
    
    