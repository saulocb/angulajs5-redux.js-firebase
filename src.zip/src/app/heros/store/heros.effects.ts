import { HerosService } from "../service/Heros.service";
import { Observable } from 'rxjs/Observable';
import { Action } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Actions, Effect } from '@ngrx/effects';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import * as herosActions from './heros.actions';



@Injectable()
export class HerosEffects {
    constructor(
        private api: HerosService,
        private actions$: Actions
    ) { }
    
    @Effect()
    loadAction$: Observable<Action> = this.actions$
        .ofType(herosActions.ActionTypes.LOAD)
        .switchMap(() => this.api.getAllHeros()
            .map(res => new herosActions.LoadCompletedAction({heros: res}))
            .catch(() => Observable.of({ type: herosActions.ActionTypes.LOAD_ERROR }))
    );


}