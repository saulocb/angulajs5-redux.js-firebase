import { Action, ActionReducer } from '@ngrx/store';
import { HerosAction, ActionTypes } from './heros.actions';

export const herosReducer: ActionReducer<any[]> = (
        state: any[] = [], action: HerosAction) => {

    switch (action.type) {
        case ActionTypes.LOAD_COMPLETED:
            return [...state, ...action.payload.heros.data];
        default:
            return state;
    }
};
