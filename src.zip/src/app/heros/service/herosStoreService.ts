import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';

import * as actions from './../store/heros.actions';

@Injectable()
export class HerosStoreService {

  heros$: Observable<any[]>;

  constructor(
    private store: Store<any>
  ) {
    this.heros$ = store.select('heros') as Observable<any[]>;
    store.dispatch(new actions.LoadAction());
  }
}
