import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions ,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';


@Injectable()
export class HerosService {
private URL = "https://s3.eu-central-1.amazonaws.com/dojomadness.com/code-challenge/heros";
  constructor(
     private http: Http    
) { }

getAllHeros(): Observable<any>{
     return this.http.get(this.URL).pipe(
      map((res: Response) => res.json())
    );
}

}
